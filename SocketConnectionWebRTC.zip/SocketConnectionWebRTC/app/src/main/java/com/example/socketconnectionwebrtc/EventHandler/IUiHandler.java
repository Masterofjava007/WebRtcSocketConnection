package com.example.socketconnectionwebrtc.EventHandler;

public interface IUiHandler {
    void notifyForViewCameraStart();
    void notifyCamera();


}
