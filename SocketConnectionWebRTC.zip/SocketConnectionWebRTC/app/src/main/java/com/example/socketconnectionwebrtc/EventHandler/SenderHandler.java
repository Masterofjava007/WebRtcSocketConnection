package com.example.socketconnectionwebrtc.EventHandler;

public class SenderHandler implements IEventListener<String> {

    @Override
    public void execute(String Payload) {

    }
}
