package com.example.socketconnectionwebrtc.Enum;

public enum MessageType {
    createRoom,
    acceptCall,
    initiateCall,
    offer,
    dismissCall
}
