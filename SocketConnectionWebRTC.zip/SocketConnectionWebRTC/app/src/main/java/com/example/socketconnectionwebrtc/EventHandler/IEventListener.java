package com.example.socketconnectionwebrtc.EventHandler;

public interface IEventListener<P> {

    void execute(P Payload);
}
