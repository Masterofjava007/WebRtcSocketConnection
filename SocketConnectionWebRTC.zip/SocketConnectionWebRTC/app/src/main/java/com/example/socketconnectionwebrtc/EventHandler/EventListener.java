package com.example.socketconnectionwebrtc.EventHandler;

public class EventListener implements IEventListener {

    @Override
    public void execute(Object Payload) {

    }
}

